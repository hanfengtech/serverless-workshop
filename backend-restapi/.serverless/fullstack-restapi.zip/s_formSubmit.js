
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'andypliu',
  applicationName: 'fullstackdemo',
  appUid: '7pPFXwP4gzm4JhfQdy',
  orgUid: 'ckTnrDJr6CJ8ZSj4Pf',
  deploymentUid: 'd8dde94e-0557-4f0f-a858-bb0f2b55d662',
  serviceName: 'fullstack-restapi',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.6',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'fullstack-restapi-dev-formSubmit', timeout: 6 };

try {
  const userHandler = require('./index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.submit, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}